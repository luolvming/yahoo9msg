-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 07 月 01 日 22:20
-- 服务器版本: 5.1.41
-- PHP 版本: 5.2.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `mydns`
--

-- --------------------------------------------------------

--
-- 表的结构 `rr`
--

CREATE TABLE IF NOT EXISTS `rr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zone` int(10) unsigned NOT NULL,
  `name` char(64) NOT NULL,
  `type` enum('A','AAAA','CNAME','HINFO','MX','NAPTR','NS','PTR','RP','SRV','TXT') DEFAULT NULL,
  `data` char(128) NOT NULL,
  `aux` int(10) unsigned NOT NULL,
  `ttl` int(10) unsigned NOT NULL DEFAULT '86400',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rr` (`zone`,`name`,`type`,`data`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=78 ;

--
-- 转存表中的数据 `rr`
--

INSERT INTO `rr` (`id`, `zone`, `name`, `type`, `data`, `aux`, `ttl`) VALUES
(1, 1, 'mvp5.com.', 'NS', 'mvp5.com.', 0, 300),
(2, 1, 'mvp5.com.', 'A', '117.79.131.116', 0, 300),
(3, 1, 'test', 'A', '123.119.253.219', 0, 300),
(4, 1, 'ns1', 'A', '211.100.26.109', 0, 300),
(5, 1, 'ns2', 'A', '211.100.26.109', 0, 300),
(6, 1, 'w2n', 'A', '220.160.110.150', 0, 300),
(7, 1, 'ftp', 'A', '58.199.39.47', 0, 300),
(8, 1, 'shadow', 'A', '222.76.205.135', 0, 300),
(9, 1, 'xyzhaopeng', 'A', '119.121.223.172', 0, 300),
(10, 1, 'wrf', 'A', '58.195.50.46', 0, 300),
(11, 1, 'langchao', 'A', '220.178.110.41', 0, 300),
(12, 1, 'chifeng', 'A', '116.115.15.13', 0, 300),
(13, 1, 'zhongguogd', 'A', '61.178.64.243', 0, 300),
(14, 1, 'cccccc', 'A', '125.70.39.48', 0, 300),
(16, 1, 'ewewjrkew', 'A', '58.195.50.52', 0, 300),
(17, 1, 'sdf', 'A', '210.34.129.133', 0, 300),
(18, 1, 'machenxu', 'A', '116.226.89.33', 0, 300),
(23, 1, 'hongyu', 'A', '219.147.198.115', 0, 300),
(20, 1, 'porada', 'A', '117.136.16.78', 0, 300),
(21, 1, 'dbzj88', 'A', '121.9.69.184', 0, 300),
(22, 1, 'gacoqhy', 'A', '218.23.60.2', 0, 300),
(25, 1, 'rain', 'A', '221.209.17.186', 0, 300),
(26, 1, 'king', 'A', '183.20.160.174', 0, 300),
(27, 1, 'hitachi', 'A', '183.20.160.174', 0, 300),
(28, 1, 'liusan', 'A', '123.150.197.66', 0, 300),
(29, 1, 'xiaowei', 'A', '220.181.93.6', 0, 300),
(30, 1, 'fackyou', 'A', '110.205.50.85', 0, 300),
(32, 1, 'looy', 'A', '222.187.221.25', 0, 300),
(33, 1, 'depth', 'A', '183.62.133.19', 0, 300),
(34, 1, 'xgmxp', 'A', '183.11.155.146', 0, 300),
(35, 1, 'wow', 'A', '124.238.192.21', 0, 300),
(36, 1, 'qzone', 'A', '113.113.238.84', 0, 300),
(37, 1, 'bb00', 'A', '61.134.28.204', 0, 300),
(38, 1, 'papa', 'A', '222.138.240.233', 0, 300),
(41, 1, 'fengxiao13', 'A', '113.77.244.212', 0, 300),
(42, 1, 'lee123', 'A', '220.181.93.6', 0, 300),
(43, 1, 'aoshi', 'A', '120.12.65.78', 0, 300),
(45, 1, 'fangxian', 'A', '113.77.243.191', 0, 300),
(46, 1, 'ajfi123', 'A', '125.73.61.84', 0, 300),
(47, 1, 'liujing', 'A', '59.174.76.212', 0, 300),
(48, 1, 'fou', 'A', '114.220.61.71', 0, 300),
(49, 1, '517233361', 'A', '182.38.206.7', 0, 300),
(50, 1, '9qu', 'A', '219.133.108.155', 0, 300),
(51, 1, 'xxmu', 'A', '124.232.158.193', 0, 300),
(53, 1, 'benbenqq', 'A', '119.134.248.73', 0, 300),
(54, 1, 'benbenqqa', 'A', '119.134.248.73', 0, 300),
(55, 1, 'ncwfj', 'A', '59.52.8.219', 0, 300),
(56, 1, 'mingjiahui', 'A', '222.88.33.222', 0, 300),
(58, 1, 'kobejie', 'A', '110.251.10.9', 0, 300),
(59, 1, 'ssddx', 'A', '112.94.20.195', 0, 300),
(60, 1, '598232947', 'A', '60.213.46.130', 0, 300),
(61, 1, 'vip888', 'A', '60.213.46.130', 0, 300),
(62, 1, 'dongzhi', 'A', '61.53.220.105', 0, 300),
(63, 1, '91lxjkw', 'A', '119.147.5.225', 0, 300),
(67, 1, 'csl', 'A', '183.67.4.253', 0, 300),
(68, 1, '2216600606', 'A', '218.29.166.34', 0, 300),
(69, 1, 'cztv666', 'A', '61.182.207.138', 0, 300),
(70, 1, 'tycpw', 'A', '113.106.101.82', 0, 300),
(71, 1, 'comegood', 'A', '218.65.122.123', 0, 300),
(72, 1, 'pbking', 'A', '110.251.237.204', 0, 300),
(73, 1, 'loveg', 'A', '118.123.140.143', 0, 300),
(74, 1, 'buse', 'A', '110.228.47.106', 0, 300),
(75, 1, '3358678', 'A', '49.117.12.232', 0, 300),
(76, 1, 'haomind', 'A', '123.65.207.8', 0, 300),
(77, 1, 'news', 'A', '106.3.83.131', 0, 300);

-- --------------------------------------------------------

--
-- 表的结构 `soa`
--

CREATE TABLE IF NOT EXISTS `soa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `origin` char(255) NOT NULL,
  `ns` char(255) NOT NULL,
  `mbox` char(255) NOT NULL,
  `serial` int(10) unsigned NOT NULL DEFAULT '1',
  `refresh` int(10) unsigned NOT NULL DEFAULT '28800',
  `retry` int(10) unsigned NOT NULL DEFAULT '7200',
  `expire` int(10) unsigned NOT NULL DEFAULT '604800',
  `minimum` int(10) unsigned NOT NULL DEFAULT '86400',
  `ttl` int(10) unsigned NOT NULL DEFAULT '86400',
  PRIMARY KEY (`id`),
  UNIQUE KEY `origin` (`origin`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `soa`
--

INSERT INTO `soa` (`id`, `origin`, `ns`, `mbox`, `serial`, `refresh`, `retry`, `expire`, `minimum`, `ttl`) VALUES
(1, 'mvp5.com.', 'mvp5.com.', 'root', 2010082601, 300, 300, 86400, 300, 300);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`) VALUES
(1, 'new', 'new'),
(2, 'shadow', '248369'),
(3, 'xyzhaopeng', 'ouzhaopeng'),
(4, '巡游の小兵', 'rongfan531'),
(5, 'laocai0049', 'wowo0049'),
(6, 'afeia', '123321'),
(7, 'zhongguogdp', '5201314'),
(8, 'cc', 'cc'),
(9, 'iamking19893', 'ybjj1'),
(10, 'iamking13', 'ybjjybjj'),
(11, 'dai', 'dai'),
(12, 'machenxu', 'machenxu'),
(13, 'chizhalongshao', 'hacker'),
(14, 'tianye306', '452911678'),
(15, 'porada', 'sand0210ok'),
(16, 'dbzj88', '43252276'),
(17, 'gacoqhy', 'gacoqhy340823'),
(18, 'hackrain', 'hacker'),
(19, 'kejianzlk', 'sskwgi'),
(20, 'lishengshen', 'lingdong1'),
(21, 'FACKYOU', 'FACKYOU'),
(22, 'fjz2003', '3528912'),
(23, 'dooy', 'dooy'),
(24, 'earend', '830228310'),
(25, 'lzp898', 'lzp168'),
(26, 'jiaohxl1314', '1982555'),
(27, '363224294', '19920424'),
(28, 'wodequn', '510964318'),
(29, 'eeeeeeeeeee', 'eeeeeeeeeee'),
(30, 'bb00', 'qisini123'),
(31, 'han8666', 'hanjingnan'),
(32, 'lengyue', 'love520'),
(33, 'fengxiaoxiao', 'KSDB3907882'),
(34, 'kongku508', '110119sxw'),
(35, 'qweqwe', 'qweqwe'),
(36, 'fangxian', 'KSDB3907882'),
(37, 'ajfi123', '803965'),
(38, 'tanyao025', '123456'),
(39, 'liujing', 'liujing'),
(40, 'hijk555', '8616001'),
(41, 'qqaazzwq', 'qqaazz'),
(42, '9qu', '123456'),
(43, 'zhmian11', '8588125'),
(44, 'qq2008dg', '123456'),
(45, 'xuannet', '773885672'),
(46, 'ncwfj', 'ghost1'),
(47, 'mingjiahui', '5buzhidaoy'),
(48, 'zouly0880', '802320'),
(49, 'kobejie', 'kobejie007sk150'),
(50, 'nyb123', 'heimao'),
(51, 'l598232947', '330330'),
(52, 'hq922461', '198533'),
(53, 'dz1414', '1314521'),
(54, '51898', '618088'),
(55, 'wenerban', 'wenerban6117'),
(56, 'blackcao', '000000'),
(57, '2216600606', '2216600606'),
(58, 'hebham', 'tesmec'),
(59, 'tycpw', 'tycpw'),
(60, 'comegood', '332600'),
(61, 'pbchu', '6153586'),
(62, 'zx10010', 'zx10010'),
(63, 'buse', 'Jane001x'),
(64, '3358678', '3358678.'),
(65, 'haomind', '555555');

-- --------------------------------------------------------

--
-- 表的结构 `user_rr`
--

CREATE TABLE IF NOT EXISTS `user_rr` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `rr_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;

--
-- 转存表中的数据 `user_rr`
--

INSERT INTO `user_rr` (`id`, `user_id`, `rr_id`) VALUES
(1, 2, 8),
(2, 3, 9),
(3, 4, 10),
(4, 5, 11),
(5, 6, 12),
(6, 7, 13),
(7, 8, 14),
(9, 10, 16),
(10, 11, 17),
(11, 12, 18),
(16, 13, 23),
(13, 15, 20),
(14, 16, 21),
(15, 17, 22),
(18, 18, 25),
(19, 19, 26),
(20, 19, 27),
(21, 20, 28),
(22, 21, 29),
(23, 21, 30),
(25, 23, 32),
(26, 24, 33),
(27, 25, 34),
(28, 27, 35),
(29, 29, 36),
(30, 30, 37),
(31, 31, 38),
(34, 33, 41),
(35, 34, 42),
(36, 35, 43),
(38, 36, 45),
(39, 37, 46),
(40, 39, 47),
(41, 40, 48),
(42, 41, 49),
(43, 42, 50),
(44, 43, 51),
(46, 44, 53),
(47, 44, 54),
(48, 46, 55),
(49, 47, 56),
(51, 49, 58),
(52, 50, 59),
(53, 51, 60),
(54, 51, 61),
(55, 53, 62),
(56, 54, 63),
(60, 56, 67),
(61, 57, 68),
(62, 58, 69),
(63, 59, 70),
(64, 60, 71),
(65, 61, 72),
(66, 62, 73),
(67, 63, 74),
(68, 64, 75),
(69, 65, 76),
(70, 1, 77);
